</div> <!-- .content -->
<footer class="footer card">
  <div>Made with ⚡ by Tom Chapoo</div>
  <div style="margin-top:6px;font-size:13px;">This theme links to the official Roblox site. Do not host or redistribute installers.</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>