<?php
/* Template Name: Front Page */
get_header(); ?>
<div class="card front-hero">
  <div class="front-left">
    <h2 style="margin-top:0">Welcome to Roblox Chapoo</h2>
    <p class="muted">This front page is part of the Roblox Chapoo Theme. Use it as the static homepage for downloads, profile and latest posts.</p>

    <div class="download-cta">
      <a class="btn" href="https://www.roblox.com/download" target="_blank" rel="noopener noreferrer">Download Roblox</a>
      <a class="btn" href="https://www.roblox.com/" target="_blank" style="background:transparent;border:1px solid rgba(255,255,255,0.06);color:#9aa4b2">Roblox Website</a>
    </div>

    <p class="muted" style="margin-top:12px">Tip: Keep this page as a link hub. This theme does NOT host installers; it links to Roblox's official pages for safety.</p>

    <div style="margin-top:18px">
      <h3 style="margin:0 0 8px 0">Latest Posts</h3>
      <?php
      $recent = new WP_Query(array('posts_per_page'=>3));
      if($recent->have_posts()): while($recent->have_posts()): $recent->the_post(); ?>
        <div class="card" style="margin-bottom:10px">
          <h4 style="margin:0;"><?php the_title(); ?></h4>
          <div class="muted"><?php the_excerpt(); ?></div>
        </div>
      <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>
  </div>

  <aside style="width:300px">
    <div class="card">
      <div style="display:flex;gap:12px;align-items:center">
        <div style="width:72px;height:72px;border-radius:12px;background:linear-gradient(135deg,#1f2937,#111827);display:flex;align-items:center;justify-content:center;font-weight:800">TC</div>
        <div>
          <strong>Tom Chapoo</strong>
          <div class="muted" style="font-size:13px">Creator & Builder</div>
        </div>
      </div>

      <p class="muted" style="margin-top:12px">Contact: <a href="#">@tomchapoo</a></p>
      <p style="margin-top:8px"><a class="btn" href="#">View Profile</a></p>
    </div>

    <div class="card" style="margin-top:12px">
      <h4 style="margin:0 0 8px 0">Theme Info</h4>
      <p class="muted" style="margin:0">Dark, responsive, lightweight. Includes menu support and post thumbnails.</p>
    </div>
  </aside>
</div>
<?php get_footer(); ?>