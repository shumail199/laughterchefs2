<?php
/* Fallback index - list posts */
get_header();
if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <article class="card" id="post-<?php the_ID(); ?>">
    <h2 class="post-title"><?php the_title(); ?></h2>
    <div class="post-meta">Posted on <?php the_time('F j, Y'); ?> <?php if (get_the_author_meta('display_name')) echo '• by '.get_the_author(); ?></div>
    <div class="post-content"><?php the_content(); ?></div>
  </article>
<?php endwhile; else: ?>
  <div class="card">No posts found.</div>
<?php endif;
get_footer();
?>